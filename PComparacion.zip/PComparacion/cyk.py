def cyk(cadena):
    n = len(cadena)
    tabla = [[set() for _ in range(n)] for _ in range(n)]

    reglas = {
        "E": [("E", "X"), ("n",)],
        "X": [("+", "E")]
    }

    for i in range(n):
        if cadena[i].isdigit():
            tabla[i][i].add("E")
        elif cadena[i] == "+":
            tabla[i][i].add("+")

  
    for l in range(2, n + 1):
        for i in range(n - l + 1):
            j = i + l - 1
            for k in range(i, j):
                for A, producciones in reglas.items():
                    for prod in producciones:
                        if len(prod) == 2:
                            B, C = prod
                            if B in tabla[i][k] and C in tabla[k + 1][j]:
                                tabla[i][j].add(A)

    return "E" in tabla[0][n - 1]
