class Predictivo:
    def __init__(self, cadena):
        self.cadena = cadena
        self.pos = 0

    def actual(self):
        if self.pos < len(self.cadena):
            return self.cadena[self.pos]
        return None

    def match(self, esperado):
        if self.actual() == esperado:
            self.pos += 1
        else:
            raise Exception("Error")

    def E(self):
        self.N()
        while self.actual() == '+':
            self.match('+')
            self.N()

    def N(self):
        if self.actual() and self.actual().isdigit():
            self.pos += 1
        else:
            raise Exception("Error")

    def parse(self):
        try:
            self.E()
            return self.pos == len(self.cadena)
        except:
            return False
