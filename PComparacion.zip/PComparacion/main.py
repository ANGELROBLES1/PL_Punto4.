import time
from cyk import cyk
from predictivo import Predictivo

def probar():
    with open("pruebas.txt") as f:
        lineas = f.readlines()

    for linea in lineas:
        cadena = linea.strip()
        if not cadena:
            continue

        print(f"\nExpresion: {cadena}")

        # CYK
        inicio = time.time()
        res_cyk = cyk(cadena)
        tiempo_cyk = time.time() - inicio

        # Predictivo
        inicio = time.time()
        parser = Predictivo(cadena)
        res_pred = parser.parse()
        tiempo_pred = time.time() - inicio

        print(f"CYK: {res_cyk} | Tiempo: {tiempo_cyk:.6f}")
        print(f"Predictivo: {res_pred} | Tiempo: {tiempo_pred:.6f}")

if __name__ == "__main__":
    probar()
